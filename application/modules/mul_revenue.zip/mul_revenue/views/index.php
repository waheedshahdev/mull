<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title;?>
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $title;?></li>
      </ol>
    </section>

    
    <?php 
                            if($this->session->flashdata("message") != ''){?>
                            <div class="alert alert-success">
                                <button class="close" data-dismiss="alert"></button>
                                <?php echo $this->session->flashdata("message");?>
                            </div>
                            <?php
                            }
                            ?>
    <section class="content">
      <div class="row">
        
        <!--/.col (left) -->
        <!-- right column -->
        <div class="col-md-12 ">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Revenue</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
           <table class="table table-responsive">
            <thead>
              <tr>
                <th>Office id</th>
                <th>Office Name</th>
                <th>District</th>
                <th>Address</th>
                <th>Action</th>
              </tr>

            </thead>
            <tbody>
            <!--  -->
            <?php foreach ($view_offices as $values):?>
            <tr>
              <td><?php echo $values->office_id;?></td>
              <td><?php echo $values->office_name;?></td>
              <td><?php echo $values->district_name;?></td>
              <td><?php echo $values->office_address;?></td>
              <td><a href="<?php echo base_url();?>mul_revenue/view_office_revenue/<?php echo $values->office_id;?>" class="btn btn-info">View Revenue</a></td>
            </tr>
           <?php endforeach;?>

            </tbody>

           </table>
          </div>

        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

  </div>