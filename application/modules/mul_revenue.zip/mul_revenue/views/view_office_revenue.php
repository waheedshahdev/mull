 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         <?php echo $title;?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> <?php echo $title;?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-4">
         
          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
             
              <h3 class="profile-username text-center">Captain name</h3>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Rating</b> <a class="pull-right">5 star</a>
                </li>
                <li class="list-group-item">
                  <b>Following</b> <a class="pull-right">543</a>
                </li>
                <li class="list-group-item">
                  <b>Friends</b> <a class="pull-right">13,287</a>
                </li>
              </ul>

              <a href="#" class="btn btn-primary"><b>Follow</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <div class="col-md-8">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
             
              <h3 class="profile-username text-center">About Captain</h3>
              <table id="example2" class="table table-bordered table-hover">
                      <thead>
                      <tr>
                        <th>ID</th>
                        <th>District</th>
                        <th>Mobile #</th>
                        <th>Status</th>
                        <th>Created</th>
                      </tr>
                      </thead>
                      <tbody>
                        
                        
                    <!--   <tr>
                        <td><?php echo $captain_profile->id;?></td>

                        <td><?php echo $captain_profile->district_name;?></td>
                        <td><?php echo $captain_profile->mobile_number;?></td>
                        <td><?php echo $status_desc;?></td>
                        <td><?php echo $captain_profile->created_at;?></td>
                     
                      </tr> -->
                      </tbody>
                     
                    </table>
                  <!--   <table id="example2" class="table table-bordered table-hover">
                      <thead>
                      <tr>
                        <th> <button type="button" class="btn btn-danger  update_status" id="<?php echo $this->uri->segment(3);?>" name="update">Block Captain</button></th>
                        <th><button type="button" class="btn btn-info  unblock_captain" id="<?php echo $this->uri->segment(3);?>" name="">UnBlock Captain</button></th>
                        <th><button type="button" class="btn btn-success  approve" id="<?php echo $this->uri->segment(3);?>" name="">Approve Captain</button></th>
                        <th><button type="button" class="btn btn-primary  update_caption_profile" id="<?php echo $this->uri->segment(3);?>" name="">Update Captain Profile</button></th>
                        <th><button type="button" class="btn btn-info  update_caption_profile" id="<?php echo $this->uri->segment(3);?>" name="" data-toggle="modal" data-target="#myModel">Switch Captain</button></th>
                      </tr>
                      </thead>

                     
                    </table> -->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-12">
          <div class="nav-tabs-custom">
            
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                <!-- Post -->
                <div class="post">
               
                    <div class="timeline-item">
                      <h3 class="timeline-header"><a href="#">Search Revenue by Date</a></h3>
                        <h1>hello</h1>
                      
                    
                    </div>
                 
                </div>
               
              </div>
         
              
             
              

              
           
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>


  </div>