<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title>Admin Home Page</title>
        <!-- Bootstrap -->
        <link href="<?php echo base_url();?>userfiles/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="<?php echo base_url();?>userfiles/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="<?php echo base_url();?>userfiles/vendors/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
        <link href="<?php echo base_url();?>userfiles/assets/styles.css" rel="stylesheet" media="screen">
        <link href="<?php echo base_url();?>userfiles/assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  --> 
 
                
      
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->




        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="<?php //echo base_url();?>userfiles/http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
         
        <script src="<?php echo base_url();?>userfiles/vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>

    </head>
    
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="#">Admin Panel</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> Vincent Gabriel <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="login.html">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                            <li class="">
                                <a href="<?php echo base_url();?>admin">Dashboard</a>
                            </li>
                            <li class="">
                                <a href="<?php echo base_url();?>admin/search">Search</a>
                            </li>
                             <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Add <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="<?php echo base_url();?>admin/add_vendor">Add Vendor</a>
                                    </li>
                                   
                                   
                                </ul>
                            </li>
                            <li class="">
                                <a href="<?php echo base_url();?>admin/car_switch">Car Switch</a>
                            </li>
                            <li class="">
                                <a href="<?php echo base_url();?>admin/captain_switch">Captain Switch</a>
                            </li>
                            <li class="">
                                <a href="#">Captain Complains</a>
                            </li>
                           <!--  <li class="dropdown">
                                <a href="#" data-toggle="dropdown" class="dropdown-toggle">Settings <b class="caret"></b>

                                </a>
                                <ul class="dropdown-menu" id="menu1">
                                    <li>
                                        <a href="#">Tools <i class="icon-arrow-right"></i>

                                        </a>
                                        <ul class="dropdown-menu sub-menu">
                                            <li>
                                                <a href="#">Reports</a>
                                            </li>
                                            <li>
                                                <a href="#">Logs</a>
                                            </li>
                                            <li>
                                                <a href="#">Errors</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="#">SEO Settings</a>
                                    </li>
                                    <li>
                                        <a href="#">Other Link</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a href="#">Other Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Other Link</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Content <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Blog</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">News</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Custom Pages</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Calendar</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="#">FAQ</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Users <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">User List</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Search</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="#">Permissions</a>
                                    </li>
                                </ul>
                            </li> -->
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>

        <?php if(isset($view_files))

                    $this->load->view($view_module.'/'.$view_files);

             ?>
        
            <hr>
            <footer>
                <p>&copy; Mul 2018</p>
            </footer>
        </div>
        <!--/.fluid-container-->

        <script src="<?php echo base_url();?>userfiles/vendors/jquery-1.9.1.min.js"></script>
        <script src="<?php echo base_url();?>userfiles/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>userfiles/vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="<?php echo base_url();?>userfiles/assets/scripts.js"></script>
              <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script> 
              <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
              <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" /> 
        <script src="<?php echo base_url();?>userfiles/assets/DT_bootstrap.js"></script>

        <script>
        $(function() {
            
        });
        </script>

        <script type="text/javascript">
        // start add vendor
            $(document).on('submit','#add_vendor_form',function(event){
            event.preventDefault();
            var name = $('#name').val();
            var cnic_number = $('#cnic_number').val();
            var email_address = $('#email_address').val();
            var mobile_number = $('#mobile_number').val();
            var cnic_front = $('#cnic_front').val().split('.').pop().toLowerCase();
            var cnic_back = $('#cnic_back').val().split('.').pop().toLowerCase();
            if(jQuery.inArray(cnic_front, ['gif', 'png', 'jpg', 'jpeg']) == -1 || jQuery.inArray(cnic_back, ['gif', 'png', 'jpg', 'jpeg']) == -1 )
            {
                alert("invalid Image File");
                $('#cnic_front'). val('');
                $('#cnic_back') . val('');

                return false;
            }
           
                $.ajax({
                    url: "<?php echo base_url();?>admin/add_vendor_data",
                    method: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    success: function(data)
                    {
                        alert("Data Saved");
                        
                        $('#add_vendor_form')[0].reset();
                        location.href = 'update_vendor/'+data;
                    }
                });
          

        });
        // end add vendor

        // start add car
         $(document).on('submit','#add_car_form',function(event){
            event.preventDefault();
            var car_reg_number = $('#car_reg_number').val();
            var district_id = $('#district_id').val();
            var car_company_id = $('#car_company_id').val();
            var car_type_id = $('#car_type_id').val();
            var car_model_id = $('#car_model_id').val();
            var car_color_id = $('#car_color_id').val();
            var car_document = $('#car_document').val().split('.').pop().toLowerCase();
            if(jQuery.inArray(car_document, ['gif', 'png', 'jpg', 'jpeg']) == -1)
            {
                alert("invalid Image File");
                $('#car_document'). val('');

                return false;
            }
           
                $.ajax({
                    url: "<?php echo base_url();?>admin/add_car_data",
                    method: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    success: function(data)
                    {
                        alert("Data Saved");
                        //alert(data);
                        $('#add_car_form')[0].reset();
                        var id = $('#vendor_id').val();
                        location.href = '<?php echo base_url();?>admin/update_vendor/'+id;
                    }
                });
          

        });
        $(document).ready(function()
        {
            $('#district_id').on('change',function(){
                        var car_reg_number = $('#car_reg_number').val();
                        var district_id = $('#district_id').val();
                $.ajax({
                    url: "<?php echo base_url();?>admin/check_car",
                    method: 'POST',
                    data: {car_reg_number: car_reg_number, district_id: district_id},
                 
                    success: function(data){
                        $('#found_message').html(data);
                       alert()

                    }

            })
                })
        });

        //end add car
 
        // start add captain
        $(document).on('submit','#add_captain_form',function(event){
            event.preventDefault();
            var captain_name = $('#captain_name').val();
            var mobile_number = $('#mobile_number').val();
            var cnic_number = $('#cnic_number').val();
            var district_id = $('#district_id').val();
            var captain_image = $('#captain_image').val().split('.').pop().toLowerCase();
            var cnic_front = $('#cnic_front').val().split('.').pop().toLowerCase();
            var cnic_back = $('#cnic_back').val().split('.').pop().toLowerCase();
            var liscence_front = $('#liscence_front').val().split('.').pop().toLowerCase();
            var liscence_back = $('#liscence_back').val().split('.').pop().toLowerCase();
            if(jQuery.inArray(captain_image, ['gif', 'png', 'jpg', 'jpeg']) == -1 || jQuery.inArray(cnic_front, ['gif', 'png', 'jpg', 'jpeg']) == -1 || jQuery.inArray(cnic_back, ['gif', 'png', 'jpg', 'jpeg']) == -1 || jQuery.inArray(liscence_front, ['gif', 'png', 'jpg', 'jpeg']) == -1 || jQuery.inArray(liscence_back, ['gif', 'png', 'jpg', 'jpeg']) == -1 )
            {
                alert("invalid Image File");
                $('#captain_image'). val('');
                $('#cnic_front'). val('');
                $('#cnic_back'). val('');
                $('#liscence_front'). val('');
                $('#liscence_back'). val('');

                return false;
            }
           
                $.ajax({
                    url: "<?php echo base_url();?>admin/add_captain_data",
                    method: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    success: function(data)
                    {
                        alert("Data Saved");
                        
                        $('#add_captain_form')[0].reset();
                        var id = $('#vendor_id').val();
                        location.href = '<?php echo base_url();?>admin/update_vendor/'+id;
                    }
                });
          

        });
        // end add captain

        // start car switch
        $(document).on('submit','#car_switch_form',function(event){
            event.preventDefault();
            var car_doc = $('#car_doc').val().split('.').pop().toLowerCase();
            var car_reg_number = $('#car_reg_number').val();
            var old_vendor_cnic = $('#old_vendor_cnic').val();
            var old_vendor_number = $('#old_vendor_number').val();
            var new_vendor_cnic = $('#new_vendor_cnic').val();
            var new_vendor_number = $('#new_vendor_number').val();
            
            if(jQuery.inArray(car_doc, ['gif', 'png', 'jpg', 'jpeg']) == -1)
            {
                alert("invalid Image File");
                $('#car_doc'). val('');

                return false;
            }
           
                $.ajax({
                    url: "<?php echo base_url();?>admin/car_switch_data",
                    method: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    success: function(data)
                    {
                        
                        
                        $('#car_switch_form')[0].reset();
                        $('#success_message').html(data);
                      
                    }
                });
          

        });
        //end car switch
       
        // start captain switch
 $(document).on('submit','#captain_switch_form',function(event){
            event.preventDefault();
           
            var captain_name_cnic = $('#captain_name_cnic').val();
            var captain_mobile = $('#captain_mobile').val();
            var old_vendor_cnic = $('#old_vendor_cnic').val();
            var new_vendor_cnic = $('#new_vendor_cnic').val();
           

                $.ajax({
                    url: "<?php echo base_url();?>admin/captain_switch_data",
                    method: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    success: function(data)
                    {
                        
                        
                        $('#captain_switch_form')[0].reset();
                        $('#success_message').html(data);
                      
                    }
                });
          
                
        });
        // end captain switch

        // show captain list
        $(document).ready(function(){  
      var dataTable = $('#user_data').DataTable({  
           "processing":true,  
           "serverSide":true,  
           "order":[],  
           "ajax":{  
                url:"<?php echo base_url() . 'admin/captain_datatable'; ?>",  
                type:"POST"  
           },  
           "columnDefs":[  
                {  
                     "targets":[0, 3, 4],  
                     "orderable":false,  
                },  
           ],  
      });  
 });          // end show captain list

            // start code for car switch data
            $(document).ready(function(){  
      var dataTable = $('#car_data').DataTable({  
           "processing":true,  
           "serverSide":true,  
           "order":[],  
           "ajax":{  
                url:"<?php echo base_url() . 'admin/car_switch_datatable'; ?>",  
                type:"POST"  
           },  
           "columnDefs":[  
                {  
                     "targets":[0, 3, 4],  
                     "orderable":false,  
                },  
           ],  
      });  
 });      
            // end code for car switch data
        </script>
        <script>
        $(function() {
            // Easy pie charts
            $('.chart').easyPieChart({animate: 1000});
        });

        
        </script>
    </body>

</html>