<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Mdl_saad extends CI_Model
{

function __construct() {
parent::__construct();
}


//Validation of Login
    public function validate_credentials($email, $password){
        $sql = "SELECT * FROM tbl_admin WHERE email='".$email."' AND password='".$password."' AND user_type = 1";
          if($query=$this->db->query($sql))
          {
              return $query->row_array();
          }
          else{
            return false;
          }
    
    }
    //end function validate

}