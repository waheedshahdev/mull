<?php
class Saad extends MX_Controller 
{

function __construct() {
parent::__construct();
$this->load->model('mdl_saad');
}

public function index()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

   
    $data['view_module'] = "saad";
    $data['view_files'] = "index";
    $this->load->module("templates");
    $this->templates->saad($data);
}
public function login()
{
    $data['title'] = 'login';
           $this->load->view('login',$data);
}
public function dashboard(){
    if($this->session->userdata['id'])
    {
       
            $data['title'] = 'Dashboard';
            $data['view_module'] = "saad";
            $data['view_files'] = "index";
            $this->load->module("templates");
            $this->templates->saad($data);
    }
    else
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        if($email=="" || $password=="" ){   
            $this->session->set_flashdata('error_msg', 'Username or Password is empty. Please try again!');
            redirect(base_url().'saad/login');    
        }
        
        $user_login = array(
            'email' => $this->input->post('email'),
            'password' => $this->input->post('password')
        );
        $data = $this->mdl_saad->validate_credentials($user_login['email'],$user_login['password']);
        if($data)
        {
            $this->session->set_userdata('id',$data['id']);
            $this->session->set_userdata('email',$data['email']);
            $this->session->set_userdata('name',$data['name']);
            $data['title'] = 'Dashboard';
            //$this->load->view('templates/main.php',$data);
            //redirect('ska_admin/dashboard',$data);
            $data['view_module'] = "saad";
            $data['view_files'] = "index";
            $this->load->module("templates");
            $this->templates->saad($data);
        }
        else
        {
            $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
            /* $data['title'] = 'SKA ADMIN | Login';
            $data['view']  = 'ska_admin/login';
            $this->load->view('ska_admin/login_simple', $data); */
            redirect('saad/login');
            //$this->load->view("login_simple.php");
        }   
    }
}
public function logout()
{
    $this->session->sess_destroy();
      redirect('saad/login', 'refresh');
}
public function vendors()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

	$data['title'] = "Vendors";
	$data['view_module'] = "saad";
    $data['view_files'] = "vendors";
    $this->load->module("templates");
    $this->templates->saad($data);
}
public function captains()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

	$data['title'] = "Captains";
	$data['view_module'] = "saad";
    $data['view_files'] = "captains";
    $this->load->module("templates");
    $this->templates->saad($data);
}

}