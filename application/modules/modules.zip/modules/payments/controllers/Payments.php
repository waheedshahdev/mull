<?php
class Payments extends MX_Controller 
{

function __construct() {
parent::__construct();
}

public function index()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $data['title'] = "Payments";
    $data['view_module'] = "payments";
    $data['view_files'] = "index";
    $this->load->module("templates");
    $this->templates->saad($data);
}
 public function getaddress($lat,$lng)
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }
    

        $url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($lat).','.trim($lng).'&sensor=false';
        $json = @file_get_contents($url);
        $data=json_decode($json);
        $status = $data->status;
        if($status=="OK")
        return $data->results[0]->formatted_address;
        else
        return false;
}
public function distance()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $latitudeFrom = 34.771747;
    $longitudeFrom = 72.360151;

    $latitudeTo = 34.015137;
    $longitudeTo = 71.524915;



//Calculate distance from latitude and longitude
    $theta = $longitudeFrom - $longitudeTo;
    $dist = sin(deg2rad($latitudeFrom)) * sin(deg2rad($latitudeTo)) +  cos(deg2rad($latitudeFrom)) * cos(deg2rad($latitudeTo)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
// riksha 12 rupee
    echo $distance = ($miles * 1.609344).' km';
echo '<br>';
    echo $dis = $distance * 20 + 80 + 180;
echo '<br>';
    echo number_format($dis,1);
    exit();

}
public function payments_list()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $this->load->model("mdl_payments");  
           $fetch_data = $this->mdl_payments->make_datatables();  
           $data = array();  
           $ride_amount_total = 0;
           $captain_amount = 0;
           $customer_pay = 0;
           $mul_amount = 0;
           $remaining_amount = 0;

           foreach($fetch_data as $row)  
           
           {  

            $status = $row->balance_type;
            if($status==N)
            {
                $status_desc = '<font color="black">None</font>';
            }
            else if($status ==M)
            {
                $status_desc = "<font color='success'>Pay to Mul</font>";
            }
            else if($status ==C){

                $status_desc = "<font color='red'>Pay to Captain</font>";
            }
            $type = $row->ride_type;
            if($type==F)
            {
                $ride = '<font color="success">Fixed</font>';
            }
            else if($type ==O)
            {
                $ride = "<font color='blue'>One Way</font>";
            }
            else if($type ==T){

                $ride = "<font color='red'>Two Way</font>";
            }
            else if($type ==R){
                $ride = "<font color='brown'>Regular</font>";
            }



            $pickup_lat = $row->pickup_lat;
            $pickup_lng = $row->pickup_lng;
            $pickup_address = $this->getaddress($pickup_lat,$pickup_lng);

            $dropoff_lat = $row->distination_lat;
            $dropoff_lng = $row->distination_lng;
            $dropoff_address = $this->getaddress($dropoff_lat,$dropoff_lng);
             $ride_amount_total = $ride_amount_total+$row->ride_amount;
             $captain_amount = $captain_amount+$row->pay_to_cap;
             $customer_pay = $customer_pay+$row->customer_pay_to_captain;
             $mul_amount = $mul_amount+$row->pay_to_us;
             $remaining_amount = $remaining_amount+$row->balance_amount;
                $sub_array = array();   
                $sub_array[] = $row->id;  
                $sub_array[] = $row->captain_name;  
                $sub_array[] = $row->customer_name;
                $sub_array[] = $pickup_address;  
                $sub_array[] = $dropoff_address;
                $sub_array[] = $row->ride_amount;
                $sub_array[] = $row->customer_pay_to_captain;
                $sub_array[] = $row->pay_to_cap;
                $sub_array[] = $row->pay_to_us;
                $sub_array[] = $row->balance_amount;
                $sub_array[] = $status_desc;
                $sub_array[] = $ride;
                $sub_array[] = $row->created_at;   
                $sub_array[] = '<a href="payments/car_profile/'.$row->id.'" name="car_profile" class="btn btn-info btn-xs">View</a>';   
                  
                $data[] = $sub_array;  
           }
           $row2[] = ""; $row2[] = ""; $row2[] = ""; $row2[] = ""; $row2[] = "Total";  $row2[] = $ride_amount_total; $row2[] = $customer_pay; $row2[] = $captain_amount; $row2[] = $mul_amount; $row2[] = $remaining_amount; $row2[] = ""; $row2[] = ""; $row2[] = ""; $row2[] = ""; 
           $data[] = $row2;
           $output = array(  
                "draw"                    =>     intval($_POST["draw"]),  
                "recordsTotal"          =>      $this->mdl_payments->get_all_data(),  
                "recordsFiltered"     =>     $this->mdl_payments->get_filtered_data(),  
                "data"                    =>     $data  
           );  
           echo json_encode($output); 


 }


 public function car_profile($id)
 {
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }
    
    $data = array();
    $data['car_data'] = get_query_data("SELECT *,tbl_vendors.name as vendor_name,tbl_vendors.cnic_number,tbl_vendors.mobile_number,tbl_vendors.created_at,
                                            tbl_vendors.id,tbl_payments.status,tbl_payments.id as carid
                                             FROM tbl_payments 
                                             -- join tbl_categories on tbl_categories.id = tbl_payments.category_id
                                             join tbl_vendors on tbl_vendors.id = tbl_payments.vendor_id 
                                             join tbl_district on tbl_district.id = tbl_payments.district_id
                                             join car_companies on car_companies.id = tbl_payments.car_company_id
                                             join car_types on car_types.id = tbl_payments.car_type_id
                                             join car_model on car_model.id = tbl_payments.car_model_id
                                            
                                             join car_color on car_color.id = tbl_payments.car_color_id WHERE tbl_payments.id = $id");

    $data['fetch_district'] = get_query_data("SELECT d.id,d.district_name FROM tbl_district as d");
    $data['fetch_car_company'] = get_query_data("SELECT c.id,c.name FROM car_companies as c");
    $data['fetch_car_type'] = get_query_data("SELECT t.id,t.type_name FROM car_types as t");
    $data['fetch_car_model'] = get_query_data("SELECT m.id,m.model FROM car_model as m");
    $data['fetch_car_color'] = get_query_data("SELECT c.id,c.color FROM car_color as c");
    $data['assign_category'] = get_query_data("SELECT *,tbl_categories.id as categoryid FROM tbl_categories");
    $data['title'] = "Car Information";
    $data['view_module'] = "payments";
    $data['view_files'] = "car_profile";
    $this->load->module("templates");
    $this->templates->saad($data);
 }







}