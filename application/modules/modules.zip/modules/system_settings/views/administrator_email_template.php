<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>MUL </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
    <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Hi <?php echo $name;?>, your Account is Successfully Created.</p>
    <h4>Here is Your Login Credentials </h4><br>
    <h5>Email:  <?php echo $email;?></h5><br>
    <h5>Password:  <?php echo $password;?></h5><br>
    <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Regards: <?php echo SITE_NAME;?> </p>

    <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px"> This is Auto generated Email </p>
    </div>
</body>
</html>