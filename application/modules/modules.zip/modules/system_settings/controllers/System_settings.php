<?php
class System_settings extends MX_Controller 
{

function __construct() {
parent::__construct();
}

public function index()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

   $data['title'] = "System Settings";
    $data['view_module'] = "system_settings";
    $data['view_files'] = "index";
    $this->load->module("templates");
    $this->templates->saad($data);
}
public function administration_access()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }
    $data['view_offices'] = get_query_data("SELECT * FROM tbl_offices");
    $data['title'] = "Add Administrator";
    $data['view_module'] = "system_settings";
    $data['view_files'] = "administration_access";
    $this->load->module("templates");
    $this->templates->saad($data);
}

public function add_administrator()
{
    $pass = rand(100000,999999);
    $data = array(
            'office_id' => $this->input->post('office_id'),
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'passowrd' => md5($pass),
            'user_type' => $this->input->post('user_type')

        );
            $status = save_data('tbl_admin',$data);
if($status !=''){
  $to_email = $this->CI->input->post('email');
  $subject = "Login Credintials";
  $data['name'] = $this->CI->input->post('name');
  $data['Email'] = $this->CI->input->post('email');
  $data['password'] = $pass;

  $message = $this->CI->load->view('administrator_email_template',$data,true);
  send_email($to_email, $subject, $message, $type='', $attachment='',$cc_to='');

}
}
public function offices()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }
    $data['view_district'] = get_query_data("SELECT * FROM tbl_district");
    $data['view_offices'] = get_query_data("SELECT *,tbl_district.district_name FROM tbl_offices JOIN tbl_district on tbl_district.id = tbl_offices.district_id");
    $data['title'] = "Add Office";
    $data['view_module'] = "system_settings";
    $data['view_files'] = "offices";
    $this->load->module("templates");
    $this->templates->saad($data);
}
public function add_office()
{
    $data = array(
            'district_id' => $this->input->post('district_id'),
            'office_name' => $this->input->post('office_name'),
            'office_phone' => $this->input->post('office_phone'),
            'office_address' => $this->input->post('office_address')

        );
    $result = save_data('tbl_offices',$data);
    if($result){
        redirect('system_settings/offices');
        $this->session->set_flashdata("message","Office Successfully Added");

    }
}

}