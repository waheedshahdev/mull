<?php
class Bookings extends MX_Controller 
{

function __construct() {
parent::__construct();
}

public function index()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $data['title'] = "Bookings";
    $data['view_module'] = "bookings";
    $data['view_files'] = "index";
    $this->load->module("templates");
    $this->templates->saad($data);
}
public function add_booking()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }
    
    $data['customer_table'] = get_query_data("SELECT * FROM tbl_customers");
    $data['captain_table'] = get_query_data("SELECT * FROM tbl_captains WHERE captain_status = 'Online'");
    $data['title'] = "Add Booking";
    $data['view_module'] = "bookings";
    $data['view_files'] = "add_booking";
    $this->load->module("templates");
    $this->templates->saad($data);
}


}