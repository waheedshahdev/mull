<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title;?>
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $title;?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title"><?php echo $title;?></h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Customer Name</label>
                <select class="form-control select2" style="width: 100%;">
                  <option selected="selected">Select Customer</option>
                  <?php foreach ($customer_table as $values):?>
                  <option value="<?php echo $values->id?>"><?php echo $values->customer_name;?>  (<?php echo $values->mobile_number;?>)</option>
              		<?php endforeach;?>
                </select>

              </div>
          </div>
              <!-- /.form-group -->
              <!-- <div class="col-md-6">
              <div class="form-group">
                <label>Select Captain</label>
                <select class="form-control select2" style="width: 100%;">
                  <option selected="selected">Select Captain</option>
                  <?php //foreach ($captain_table as $values):?>
                  <option value="<?php //echo $values->id?>"><?php //echo $values->captain_name;?>  (<?php //echo $values->mobile_number;?>)</option>
              		<?php //endforeach;?>
                </select>
              </div>
            </div> -->
            </div>

            <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Pick up Location</label>
                        <input class="form-control"  type="text" name="address1" id="searchTextField"  placeholder="Enter Pick Up point"/>
              </div>
          </div>
              <div class="col-md-6">
              <div class="form-group">
                <label>Drop off Location</label>
                <input class="form-control" type="text" name="address2" id="searchTextField2"  placeholder="Enter Destination"/>
              </div>
              <!-- /.form-group -->
            </div>
            </div>
            
            <input type="submit" id="submit" style="width:100%;" class="btn btn-info" value="Search Captain">
            <br>
            <br>
       <table width="100%" id="results">
            <tr>
              <td><div id="map" style="height:500px;border:1px solid #000;">Google Map</div></td>
              <td></td>
            </tr>
          </table>
          </div>
          <!-- /.row -->
        </div>
     
      </div>

    

    </section>
  </div>
  

<script>
      function initMap() {
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;

/*var defaultBounds = new google.maps.LatLngBounds(
            new google.maps.LatLng(4.207917999999999, 101.9827997),//sw bounds
            new google.maps.LatLng(4.209196599999999, 101.9833456));*///ne bounds
            var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 7, 
            center: new google.maps.LatLng(35.222711,72.425815)
        });
        directionsDisplay.setMap(map);
	/*var options = {
    types: ['geocode'],
    strictBounds: true,
    componentRestrictions: {country: 'MY'}
}; 	
	 var option2 = {
    types: ['geocode'],
    strictBounds: true,
    componentRestrictions: {country: 'MY'}
}; 	*/
		var input =(document.getElementById('searchTextField'));
		var input2 =(document.getElementById('searchTextField2'));
		//var strictBounds = document.getElementById('strict-bounds-selector');
		 var autocomplete = new google.maps.places.Autocomplete(input);
		 var autocomplete2 = new google.maps.places.Autocomplete(input2);
   
        document.getElementById('submit').addEventListener('click', function() {

          		calculateAndDisplayRoute(directionsService, directionsDisplay);
        });
      }
      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
        var waypts = [];
       /* var checkboxArray = document.getElementById('waypoints');
        for (var i = 0; i < checkboxArray.length; i++) {
          if (checkboxArray.options[i].selected) {
            waypts.push({
              location: checkboxArray[i].value,
              stopover: true
            });
          }
        }*/
        directionsService.route({
          origin: document.getElementById('searchTextField').value,
          destination: document.getElementById('searchTextField2').value,
          waypoints: waypts,
          optimizeWaypoints: true,
          travelMode: 'DRIVING'
        }, function(response, status) {
          if (status === 'OK') {
			  $('#book_now').attr('disabled',false);
	
            directionsDisplay.setDirections(response);
            var route = response.routes[0];
            var summaryPanel = document.getElementById('directions-panel');
			//document.getElementById('calctest').value = distance.text;
            summaryPanel.innerHTML = '';
            // For each route, display summary information.
            for (var i = 0; i < route.legs.length; i++) {
              var routeSegment = i + 1;
			  
			   var return_rider;
				var checkbox_male_val;
				if(document.getElementById("checkbox_return").checked == true){
					return_rider = 1;
				} else {
					return_rider = 0;
				}
				
			  var final_km = 0;
			  if(return_rider == 0){
				  summaryPanel.innerHTML += '<b><br>Route: ' + routeSegment +'</b><br>';
				  summaryPanel.innerHTML += route.legs[i].start_address + '<br><br>to<br><br> ';
				  summaryPanel.innerHTML += route.legs[i].end_address + '<br><br>';
				  summaryPanel.innerHTML += 'Total Distance: '+route.legs[i].distance.text + '<br>';
				  var km_fare = route.legs[i].distance.text;
				  
				  var fare_km_split = km_fare.split(" ");
				  var final_km = parseFloat(fare_km_split[0]);
				  
				  
			  } else if(return_rider == 1){
				  summaryPanel.innerHTML += '<b><br>Depart: </b><br>';
				  summaryPanel.innerHTML += route.legs[i].start_address + ' &nbsp; <b>To</b> &nbsp; ';
				  summaryPanel.innerHTML += route.legs[i].end_address;
				  summaryPanel.innerHTML += ' [Distance: '+ route.legs[i].distance.text + ']<br>';
				  
				  summaryPanel.innerHTML += '<b><br>Return: </b><br>';
				  summaryPanel.innerHTML += route.legs[i].end_address + '&nbsp; <b>To</b> &nbsp;';
				  summaryPanel.innerHTML += route.legs[i].start_address;
				  summaryPanel.innerHTML += ' [Distance: '+ route.legs[i].distance.text + ']<br><br>';
				  
				  var km_for_return = route.legs[i].distance.text;
				  
				  var fare_km_split = km_for_return.split(" ");
			  	  var fare_km_split_one = parseFloat(fare_km_split[0]);
				  var final_km = 2 * fare_km_split_one;
				  
				  
				  summaryPanel.innerHTML += 'Total Distance: '+ final_km + 'Km<br>';
			  }

            } 
          } else {
            window.alert('Directions request failed due to ' + status);
          }
        });
      }
    </script> 
<script
src="https://maps.googleapis.com/maps/api/js?3.27&key=AIzaSyDw2kLzHkMOg6Qvgf1WQxIHi5zirB3lX2g&libraries=places&callback=initMap">
</script>
