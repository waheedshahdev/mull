<?php
class Admin extends MX_Controller 
{

function __construct() {
parent::__construct();

//$this->load->model('mdl_admin_model');
}

public function index()
{
    $data['view_module'] = "admin";
    $data['view_files'] = "index";
    $this->load->module("templates");
    $this->templates->user_admin($data);
}
public function search()
{
	$data['view_module'] = "admin";
    $data['view_files'] = "search";
    $this->load->module("templates");
    $this->templates->user_admin($data);
}
public function add_vendor()
{
    
	$data['title'] = "Add Vendor";
	$data['view_module'] = "admin";
    $data['view_files'] = "add_vendor";
    $this->load->module("templates");
    $this->templates->user_admin($data);
 }  
public function add_vendor_data()
{
   $data = array(
                    'name' => $this->input->post('name'),
                    'cnic_number' => $this->input->post('cnic_number'),
                    'email_address' => $this->input->post('email_address'),
                    'mobile_number' => $this->input->post('mobile_number'),
                    'cnic_front' => $this->upload_image(),
                    'cnic_back' => $this->upload_image2()

        );

  $result =  save_data('tbl_vendors',$data);
        echo $result;
}
public function upload_image()
{
    if(isset($_FILES['cnic_front']))
    {
        $cnic_front = explode('.', $_FILES['cnic_front']['name']);
        $new_name = rand().'.'.$cnic_front[1];
        //$destination = '/vendor_images'.$new_name;
        move_uploaded_file($_FILES['cnic_front']['tmp_name'], './userfiles/vendor_images/'.$new_name);
        return $new_name;

    

    }
}
public function upload_image2()
{
    if(isset($_FILES['cnic_back']))
    {
        $cnic_back = explode('.', $_FILES['cnic_back']['name']);
        $new_name = rand().'.'.$cnic_back[1];
       // $destination = 'vendor_images'.$new_name;
        move_uploaded_file($_FILES['cnic_back']['tmp_name'], './userfiles/vendor_images/'.$new_name);
        return $new_name;

    }
}
public function add_car()
{
    // $submit = $this->input->post('submit');
    // if($submit == 'Submit')
    // {



    $data['view_district'] = get_query_data('SELECT * FROM tbl_district');
    $data['view_color'] = get_query_data('SELECT * FROM car_color');
    $data['view_model'] = get_query_data('SELECT * FROM car_model');
    $data['view_car_company'] = get_query_data('SELECT * FROM car_companies');
    $data['view_car_type'] = get_query_data('SELECT * FROM car_types');
    $data['title'] = "Add Car";
    $data['view_module'] = "admin";
    $data['view_files'] = "add_car";
    $this->load->module("templates");
    $this->templates->user_admin($data);
}
public function add_car_data()
{

    $data = array(
                        'vendor_id' => $this->input->post('vendor_id'),
                        'car_reg_number' => $this->input->post('car_reg_number'),
                        'district_id' => $this->input->post('district_id'),
                        'car_company_id' => $this->input->post('car_company_id'),
                        'car_type_id' => $this->input->post('car_type_id'),
                        'car_model_id' => $this->input->post('car_model_id'),
                        'car_color_id' => $this->input->post('car_color_id'),
                        'car_document' => $this->upload_car_document()

            );
        save_data('tbl_cars',$data);

       // redirect($this->update_vendor.'/'.$this->uri->segment(3));

}
public function check_car()
{
    $car_reg_number = $this->input->post('car_reg_number');
    $district_id = $this->input->post('district_id');
    $result = get_query_data("SELECT car_reg_number, district_id FROM tbl_cars WHERE car_reg_number = '$car_reg_number' and district_id = $district_id");
if($result)
{
    echo '<div class="alert alert-success">
                                <button class="close" data-dismiss="alert"></button>
                        Data found
            </div>';

}


}

public function upload_car_document()
{
    if(isset($_FILES['car_document']))
    {
        $car_document = explode('.', $_FILES['car_document']['name']);
        $new_name = rand().'.'.$car_document[1];
       // $destination = 'vendor_images'.$new_name;
        move_uploaded_file($_FILES['car_document']['tmp_name'], './userfiles/car_document/'.$new_name);
        return $new_name;

    }
}
public function add_captain()
{
    $data['view_district'] = get_query_data('SELECT * FROM tbl_district');
    $data['title'] = "Add Captain";
    $data['view_module'] = "admin";
    $data['view_files'] = "add_captain";
    $this->load->module("templates");
    $this->templates->user_admin($data);
}
public function add_captain_data()
{
     $data = array(
                        
                        'vendor_id' => $this->input->post('vendor_id'),
                        'captain_name' => $this->input->post('captain_name'),
                        'mobile_number' => $this->input->post('mobile_number'),
                        'cnic_number' => $this->input->post('cnic_number'),
                        'district_id' => $this->input->post('district_id'),
                        'captain_image' => $this->upload_captain_image(),
                        'cnic_front' => $this->upload_cnic_front(),
                        'cnic_back' => $this->upload_cnic_back(),
                        'liscence_front' => $this->upload_liscence_front(),
                        'liscence_back' => $this->upload_liscence_back(),

            );
        save_data('tbl_captains',$data);
}
public function upload_captain_image()
{
    if(isset($_FILES['captain_image']))
    {
        $captain_image = explode('.', $_FILES['captain_image']['name']);
        $new_name = rand().'.'.$captain_image[1];
       // $destination = 'vendor_images'.$new_name;
        move_uploaded_file($_FILES['captain_image']['tmp_name'], './userfiles/captain_images/'.$new_name);
        return $new_name;

    }
}
public function upload_cnic_front()
{
    if(isset($_FILES['cnic_front']))
    {
        $cnic_front = explode('.', $_FILES['cnic_front']['name']);
        $new_name = rand().'.'.$cnic_front[1];
       // $destination = 'vendor_images'.$new_name;
        move_uploaded_file($_FILES['cnic_front']['tmp_name'], './userfiles/captain_images/'.$new_name);
        return $new_name;

    }
}
public function upload_cnic_back()
{
    if(isset($_FILES['cnic_back']))
    {
        $cnic_back = explode('.', $_FILES['cnic_back']['name']);
        $new_name = rand().'.'.$cnic_back[1];
       // $destination = 'vendor_images'.$new_name;
        move_uploaded_file($_FILES['cnic_back']['tmp_name'], './userfiles/captain_images/'.$new_name);
        return $new_name;

    }
}
public function upload_liscence_front()
{
    if(isset($_FILES['liscence_front']))
    {
        $liscence_front = explode('.', $_FILES['liscence_front']['name']);
        $new_name = rand().'.'.$liscence_front[1];
       // $destination = 'vendor_images'.$new_name;
        move_uploaded_file($_FILES['liscence_front']['tmp_name'], './userfiles/captain_images/'.$new_name);
        return $new_name;

    }
}
public function upload_liscence_back()
{
    if(isset($_FILES['liscence_back']))
    {
        $liscence_back = explode('.', $_FILES['liscence_back']['name']);
        $new_name = rand().'.'.$liscence_back[1];
       // $destination = 'vendor_images'.$new_name;
        move_uploaded_file($_FILES['liscence_back']['tmp_name'], './userfiles/captain_images/'.$new_name);
        return $new_name;

    }
}
public function car_switch()
{
    $car_switching = get_query_data("SELECT * FROM tbl_car_switch");
    $data['car_switch'] = $car_switching;
    $data['title'] = "Car Switching";
    $data['view_module'] = "admin";
    $data['view_files'] = "car_switch";
    $this->load->module("templates");
    $this->templates->user_admin($data);
}
public function car_switch_data()
{
    $data = array(
                    'car_doc' => $this->upload_car_doc(),
                    'car_reg_number' => $this->input->post('car_reg_number'),
                    'old_vendor_cnic' => $this->input->post('old_vendor_cnic'),
                    'old_vendor_number' => $this->input->post('old_vendor_number'),
                    'new_vendor_cnic' => $this->input->post('new_vendor_cnic'),
                    'new_vendor_number' => $this->input->post('new_vendor_number')

        );
    $result = save_data('tbl_car_switch',$data);
    if($result){
        echo '<div class="alert alert-success">
                                <button class="close" data-dismiss="alert"></button>
                        Car switch Successfully!
            </div>';
    }
}
public function upload_car_doc()
{
    if(isset($_FILES['car_doc']))
    {
        $car_doc = explode('.', $_FILES['car_doc']['name']);
        $new_name = rand().'.'.$car_doc[1];
       // $destination = 'vendor_images'.$new_name;
        move_uploaded_file($_FILES['car_doc']['tmp_name'], './userfiles/car_switch_images/'.$new_name);
        return $new_name;

    }
}
public function captain_switch()
{

    //$data['captain_data'] = get_query_data("SELECT * FROM tbl_captain_switch");
    $data['title'] = "Captain Switching";
    $data['view_module'] = "admin";
    $data['view_files'] = "captain_switch";
    $this->load->module("templates");
    $this->templates->user_admin($data);
}
public function captain_datatable()
{
    $this->load->model("mdl_admin");  
           $fetch_data = $this->mdl_admin->make_datatables();  
           $data = array();  
           foreach($fetch_data as $row)  
           {  

            $status = $row->status;
            if($status==0)
            {
                $status_label= 'danger';
                $status_desc = 'Pending';
            }
            else if($status ==1)
            {
                $status_label = "success";
                $status_desc = "Resolved";
            }
            else{
                $status_label = "info";
                $status_desc = "Blocked";
            }

                $sub_array = array();   
                $sub_array[] = $row->id;  
                $sub_array[] = $row->captain_name_cnic;  
                $sub_array[] = $row->captain_mobile;  
                $sub_array[] = $row->old_vendor_cnic;  
                $sub_array[] = $row->new_vendor_cnic;  
                $sub_array[] = $row->created_at;  
                $sub_array[] = '<span class="label label-<?php echo $status_label?>">'.$status_desc;//$row->status;  
                $sub_array[] = '<button type="button" name="view" id="'.$row->id.'" class="btn btn-info btn-xs">View</button>';  
                $data[] = $sub_array;  
           }  
           $output = array(  
                "draw"                    =>     intval($_POST["draw"]),  
                "recordsTotal"          =>      $this->mdl_admin->get_all_data(),  
                "recordsFiltered"     =>     $this->mdl_admin->get_filtered_data(),  
                "data"                    =>     $data  
           );  
           echo json_encode($output); 



       }
public function captain_switch_data()
{
    $data = array(
                    'captain_name_cnic' => $this->input->post('captain_name_cnic'),
                    'captain_mobile' => $this->input->post('captain_mobile'),
                    'old_vendor_cnic' => $this->input->post('old_vendor_cnic'),
                    'new_vendor_cnic' => $this->input->post('new_vendor_cnic')

        );
    $result = save_data('tbl_captain_switch',$data);
    if($result){
        echo '<div class="alert alert-success">
                                <button class="close" data-dismiss="alert"></button>
                        Captain switch Successfully!
            </div>';
    }
}
public function car_switch_datatable()
{
     $this->load->model("mdl_admin");  
           $fetch_data = $this->mdl_admin->make_datatables_for_car();  
           $data = array();  
           foreach($fetch_data as $row)  
           {  

            $status = $row->status;
            if($status==0)
            {
                $status_label= 'danger';
                $status_desc = 'Pending';
            }
            else if($status ==1)
            {
                $status_label = "success";
                $status_desc = "Resolved";
            }
            else{
                $status_label = "info";
                $status_desc = "Blocked";
            }

                $sub_array = array();   
                $sub_array[] = $row->id;  
                $sub_array[] = $row->car_reg_number;  
                $sub_array[] = $row->old_vendor_cnic;  
                $sub_array[] = $row->new_vendor_cnic;
                 
                $sub_array[] = '<span class="label label-<?php echo $status_label?>">'.$status_desc;//$row->status; 
                $sub_array[] = $row->created_at; 
                $sub_array[] = '<button type="button" name="view" id="'.$row->id.'" class="btn btn-info btn-xs">View</button>';  
                $data[] = $sub_array;  
           }  
           $output = array(  
                "draw"                    =>     intval($_POST["draw"]),  
                "recordsTotal"          =>      $this->mdl_admin->get_all_data_for_car(),  
                "recordsFiltered"     =>     $this->mdl_admin->get_filtered_data_for_car(),  
                "data"                    =>     $data  
           );  
           echo json_encode($output); 
}
public function update_vendor($id)
{
    $result = get_query_data("SELECT * FROM tbl_vendors WHERE id = $id");
    $view_captain = get_query_data("SELECT * FROM tbl_captains join tbl_district on tbl_captains.district_id = tbl_district.id where vendor_id = $id");
    $view_cars = get_query_data("SELECT *,tbl_cars.id FROM tbl_cars join car_companies on tbl_cars.car_company_id = car_companies.id 
                                    join car_types on tbl_cars.car_type_id = car_types.id 
                                    join tbl_district on tbl_cars.district_id = tbl_district.id
                                    join car_color on tbl_cars.car_color_id = car_color.id 
                                    join car_model on tbl_cars.car_model_id = car_model.id WHERE vendor_id = $id"); 
    $data['view_car'] = $view_cars;
    $data['captains'] = $view_captain;
    $data['view'] = $result;
    $data['title'] = "Add Car and Captain";
    $data['view_module'] = "admin";
    $data['view_files'] = "update_vendor";
    $this->load->module("templates");
    $this->templates->user_admin($data);

}

}