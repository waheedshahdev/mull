<?php
class Captains extends MX_Controller 
{

function __construct() {
parent::__construct();
}

public function index()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $data['title'] = "Captains";
    $data['view_module'] = "captains";
    $data['view_files'] = "index";
    $this->load->module("templates");
    $this->templates->saad($data);
}
public function captains_list()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $this->load->model("mdl_captains");  
           $fetch_data = $this->mdl_captains->make_datatables();  
           $data = array();  
           foreach($fetch_data as $row)  
           {  

            $status = $row->status;
            if($status==P)
            {
                $status_label= '';
                $status_desc = '<font color="info">Pending</font>';
            }
            else if($status ==A)
            {
                $status_label = "success";
                $status_desc = "<font color='success'>Approved</font>";
            }
            else if($status ==B){
                $status_label = "info";
                $status_desc = "<font color='red'>Blocked</font>";
            }

                $sub_array = array();   
                $sub_array[] = $row->id;  
                $sub_array[] = $row->captain_name;  
                $sub_array[] = $row->cnic_number;  
                $sub_array[] = $row->mobile_number;
                $sub_array[] = $row->district_name;   
                $sub_array[] = $row->created_at;  
                $sub_array[] = $status_desc;//$row->status;  
                $sub_array[] = $row->updated_at;
                $sub_array[] = '<a href="captains/captain_profile/'.$row->id.'" name="captain_profile" class="btn btn-info btn-xs">View</a> 
                <a href="captains/captain_profile/'.$row->id.'" name="captain_profile" class="btn btn-danger btn-xs">Block</a>';   
                  
                $data[] = $sub_array;  
           }  
           $output = array(  
                "draw"                    =>     intval($_POST["draw"]),  
                "recordsTotal"          =>      $this->mdl_captains->get_all_data(),  
                "recordsFiltered"     =>     $this->mdl_captains->get_filtered_data(),  
                "data"                    =>     $data  
           );  
           echo json_encode($output); 


 }
 public function captain_profile($id)
 {
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $data['captain_data'] = get_query_data("SELECT *,tbl_vendors.id as vendorid ,tbl_vendors.cnic_number,tbl_vendors.mobile_number,tbl_vendors.created_at,
                                            tbl_captains.cnic_front,tbl_captains.cnic_back,tbl_captains.id,tbl_captains.status
                                             FROM tbl_captains join tbl_vendors on tbl_vendors.id = tbl_captains.vendor_id 
                                             join tbl_district on tbl_district.id = tbl_captains.district_id WHERE tbl_captains.id = $id");

    
    $data['captain_today_rides'] = get_query_data("SELECT * FROM tbl_rides join tbl_calculation on tbl_calculation.ride_id = tbl_rides.id
                                                    join tbl_customers on tbl_customers.id = tbl_rides.customer_id WHERE captain_id = $id AND DATE(tbl_rides.created_at) = CURDATE()");
    $data['title'] = "Captain Profile";
    $data['view_module'] = "captains";
    $data['view_files'] = "captain_profile";
    $this->load->module("templates");
    $this->templates->saad($data);
 }
public function switch_captain()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

   $id = $this->input->post('update_id');
    $data = array(
            'vendor_id' => $this->input->post('vendor_id')

        );
    update_data('tbl_captains',$data,$id);

    update_data('tbl_captain_switch','status = 1',$id);
    redirect('captains/captain_profile/'.$id);
}
public function block_captain()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $id = $this->input->post('captain_id');
    $data = array(
        'status' => 'B'
        );
    update_data('tbl_captains',$data,$id);
    echo "Captain is Blocked";
}
public function approve_captain()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $id = $this->input->post('captain_id');
    $data = array(
        'status' => 'A'
        );
    update_data('tbl_captains',$data,$id);
    echo "Captain Approved Successfully";
}
public function captain_switching_list()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $data['title'] = "Captain Switching List";
    $data['view_module'] = "captains";
    $data['view_files'] = "captain_switching";
    $this->load->module("templates");
    $this->templates->saad($data); 
}
public function captain_switch_datatable()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }

    $this->load->model("mdl_captains");  
           $fetch_data = $this->mdl_captains->make_datatables_for_switch();  
           $data = array();  
           foreach($fetch_data as $row)  
           {  

            $status = $row->status;
            if($status==0)
            {
                $status_label= '';
                $status_desc = '<font color="info">Pending</font>';
            }
            else if($status ==1)
            {
                $status_label = "success";
                $status_desc = "<font color='success'>Resolved</font>";
            }
            else{
                $status_label = "info";
                $status_desc = "<font color='red'>Blocked</font>";
            }

                $sub_array = array();   
                $sub_array[] = $row->id;  
                $sub_array[] = $row->captain_name_cnic;  
                $sub_array[] = $row->captain_mobile;  
                $sub_array[] = $row->old_vendor_cnic;
                $sub_array[] = $row->new_vendor_cnic;   
                $sub_array[] = $row->created_at;  
                $sub_array[] = $status_desc;//$row->status;  
                $sub_array[] = $row->updated_at;
                $sub_array[] = '<a href="captains/captain_profile/'.$row->id.'" name="captain_profile" class="btn btn-info btn-xs">View</a> 
                <a href="captains/captain_profile/'.$row->id.'" name="captain_profile" class="btn btn-danger btn-xs">Block</a>';   
                  
                $data[] = $sub_array;  
           }  
           $output = array(  
                "draw"                    =>     intval($_POST["draw"]),  
                "recordsTotal"          =>      $this->mdl_captains->get_all_data_for_switch(),  
                "recordsFiltered"     =>     $this->mdl_captains->get_filtered_data_for_switch(),  
                "data"                    =>     $data  
           );  
           echo json_encode($output);


    
}
public function captain_new()
{
    if($this->session->userdata('id') == ''){
        redirect('saad/login');
    }
    
    $data['title'] = " Captain Profile";
    $data['view_module'] = "captains";
    $data['view_files'] = "captain_new";
    $this->load->module("templates");
    $this->templates->saad($data); 

}









}
